import esptool
import os
import sys

# get the abs path of the scripts directory.
dirpath = os.path.dirname(sys.argv[0])

# generate abs paths for the ino and spiffs bin file.
sketch = '\\'.join( [dirpath , 'PxlNode_UDP_Sketch_1.0.bin'] )
spiffs = '\\'.join( [dirpath , 'PxlNode_UDP_Spiffs_1.0.bin'] )

# assemble the command argument list.
command = ['write_flash', '0x00000', sketch, '0x100000', spiffs]

# attempt to program the esp connected to the computer. 
esptool.main(command)
